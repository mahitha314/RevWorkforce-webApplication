package com.workforce.model;

import jakarta.persistence.*;
@Entity
@Table(name = "leave_balances")
public class LeaveBalance {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long leaveBalanceId;

    @ManyToOne
    @JoinColumn(name = "employee_id", nullable = false)
    private Employee employee;

    @Column(name = "leave_type", nullable = false, length = 50)
    private String leaveType; 

    @Column(name = "total_leaves", nullable = false)
    private int totalLeaves;

    @Column(name = "used_leaves", nullable = false)
    private int usedLeaves;

    @Column(name = "remaining_leaves", nullable = false)
    private int remainingLeaves;
   
    public LeaveBalance() {}
  
    public LeaveBalance(Employee employee, String leaveType, int totalLeaves, int usedLeaves, int remainingLeaves) {
        this.employee = employee;
        this.leaveType = leaveType;
        this.totalLeaves = totalLeaves;
        this.usedLeaves = usedLeaves;
        this.remainingLeaves = remainingLeaves;
    }

    public Long getLeaveBalanceId(){return leaveBalanceId;}
    public void setLeaveBalanceId(Long leaveBalanceId){this.leaveBalanceId=leaveBalanceId;}

    public Employee getEmployee(){return employee;}
    public void setEmployee(Employee employee){this.employee=employee;}

    public String getLeaveType(){return leaveType;}
    public void setLeaveType(String leaveType){this.leaveType=leaveType;}

    public int getTotalLeaves(){return totalLeaves;}
    public void setTotalLeaves(int totalLeaves){this.totalLeaves=totalLeaves;}

    public int getUsedLeaves(){return usedLeaves;}
    public void setUsedLeaves(int usedLeaves){this.usedLeaves=usedLeaves;}

    public int getRemainingLeaves(){return remainingLeaves;}
    public void setRemainingLeaves(int remainingLeaves){this.remainingLeaves=remainingLeaves;}
    
}